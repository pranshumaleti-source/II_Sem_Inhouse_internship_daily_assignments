<?php
/**
 * Database configuration
 * Update these credentials to match your local MySQL / XAMPP / WAMP setup.
 */
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');          // default XAMPP password is empty
define('DB_NAME', 'ai_product_generator');

// Create connection using MySQLi
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error .
        "<br>Make sure MySQL is running and you have imported database/schema.sql");
}

$conn->set_charset('utf8mb4');
