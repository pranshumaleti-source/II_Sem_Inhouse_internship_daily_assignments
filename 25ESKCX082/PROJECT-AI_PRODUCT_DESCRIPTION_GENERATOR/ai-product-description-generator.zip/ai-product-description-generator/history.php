<?php
$pageTitle = "History";
require 'config/db.php';
include 'includes/header.php';

$isAdmin = isset($_SESSION['admin_id']);

$result = $conn->query("SELECT * FROM descriptions ORDER BY created_at DESC");
?>

<section class="hero" style="padding-top:32px;">
    <h1>Generated Description History</h1>
    <p>Browse, search, and manage every product description you've generated and saved.</p>
</section>

<?php if (isset($_GET['deleted'])): ?>
    <div class="alert alert-success">Description deleted successfully.</div>
<?php endif; ?>
<?php if (isset($_GET['updated'])): ?>
    <div class="alert alert-success">Description updated successfully.</div>
<?php endif; ?>

<div class="search-bar">
    <input type="text" id="history-search" placeholder="🔍 Search by product name, category, or keyword...">
</div>

<?php if ($result && $result->num_rows > 0): ?>
<div class="card" style="overflow-x:auto;">
    <table id="history-table">
        <thead>
            <tr>
                <th>Product</th>
                <th>Category</th>
                <th>Tone</th>
                <th>Description</th>
                <th>Created</th>
                <?php if ($isAdmin): ?><th>Actions</th><?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td data-label="Product"><strong><?php echo htmlspecialchars($row['product_name']); ?></strong></td>
                <td data-label="Category"><?php echo htmlspecialchars($row['category']); ?></td>
                <td data-label="Tone"><span class="badge"><?php echo htmlspecialchars($row['tone']); ?></span></td>
                <td data-label="Description">
                    <div class="desc-preview"><?php echo htmlspecialchars(mb_strimwidth($row['description'], 0, 140, '...')); ?></div>
                </td>
                <td data-label="Created"><?php echo date('d M Y, h:i A', strtotime($row['created_at'])); ?></td>
                <?php if ($isAdmin): ?>
                <td data-label="Actions">
                    <div class="actions-row" style="margin-top:0;">
                        <a href="edit.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-secondary">Edit</a>
                        <form class="delete-form" action="delete.php" method="POST" style="display:inline;">
                            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                        </form>
                    </div>
                </td>
                <?php endif; ?>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
<?php else: ?>
    <div class="card empty-state">
        <h3>No descriptions yet</h3>
        <p>Head to the <a href="index.php">Generator</a> and create your first AI-style product description.</p>
    </div>
<?php endif; ?>

<?php if (!$isAdmin): ?>
    <p style="text-align:center; color:var(--muted); font-size:0.85rem;">
        <a href="login.php">Log in as admin</a> to edit or delete saved descriptions.
    </p>
<?php endif; ?>

<?php
$conn->close();
include 'includes/footer.php';
?>
