// =====================================================================
// AI Product Description Generator — Frontend Logic
// =====================================================================

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('generator-form');
    if (form) initGeneratorForm();

    const searchInput = document.getElementById('history-search');
    if (searchInput) initHistorySearch();

    initDeleteConfirmations();
});

/* ---------------------------------------------------------------
   Generator form (index.php)
--------------------------------------------------------------- */
function initGeneratorForm() {
    const form = document.getElementById('generator-form');
    const loader = document.getElementById('loader');
    const resultPanel = document.getElementById('result-panel');
    const generatedText = document.getElementById('generated-text');
    const seoTags = document.getElementById('seo-tags');
    const wordCountEl = document.getElementById('word-count');
    const copyBtn = document.getElementById('copy-btn');
    const saveBtn = document.getElementById('save-btn');
    const generateBtn = document.getElementById('generate-btn');

    let lastResult = null;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        loader.classList.add('visible');
        resultPanel.classList.remove('visible');
        generateBtn.disabled = true;

        const formData = new FormData(form);

        try {
            const response = await fetch('generate.php', {
                method: 'POST',
                body: formData
            });
            const data = await response.json();

            if (!response.ok || data.error) {
                alert(data.error || 'Something went wrong. Please check your inputs.');
                return;
            }

            lastResult = data;
            resultPanel.classList.add('visible');
            typeOutText(generatedText, data.description);
            wordCountEl.textContent = data.word_count + ' words';

            seoTags.innerHTML = '';
            data.seo_keywords.split(',').forEach(k => {
                const span = document.createElement('span');
                span.className = 'tag';
                span.textContent = k.trim();
                seoTags.appendChild(span);
            });

            resultPanel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        } catch (err) {
            alert('Could not reach the server. Please check your PHP/MySQL setup is running.');
            console.error(err);
        } finally {
            loader.classList.remove('visible');
            generateBtn.disabled = false;
        }
    });

    copyBtn.addEventListener('click', () => {
        if (!lastResult) return;
        navigator.clipboard.writeText(lastResult.description).then(() => {
            const original = copyBtn.textContent;
            copyBtn.textContent = '✅ Copied!';
            setTimeout(() => { copyBtn.textContent = original; }, 1500);
        });
    });

    saveBtn.addEventListener('click', async () => {
        if (!lastResult) return;
        saveBtn.disabled = true;
        saveBtn.textContent = 'Saving...';

        try {
            const body = new URLSearchParams(lastResult);
            const response = await fetch('save.php', { method: 'POST', body });
            const data = await response.json();

            if (data.success) {
                saveBtn.textContent = '✅ Saved to History';
            } else {
                saveBtn.textContent = '💾 Save to History';
                alert(data.error || 'Could not save. Have you imported database/schema.sql?');
            }
        } catch (err) {
            alert('Could not reach the server to save.');
            saveBtn.textContent = '💾 Save to History';
        } finally {
            saveBtn.disabled = false;
        }
    });
}

/** Simple typewriter effect so the result feels "AI-generated live" */
function typeOutText(el, text) {
    el.textContent = '';
    el.classList.add('typing-cursor');
    let i = 0;
    const speed = Math.max(4, Math.min(14, Math.floor(800 / text.length)));

    function step() {
        if (i < text.length) {
            el.textContent += text.charAt(i);
            i++;
            setTimeout(step, speed);
        } else {
            el.classList.remove('typing-cursor');
        }
    }
    step();
}

/* ---------------------------------------------------------------
   History page search/filter (history.php) — client-side filter
--------------------------------------------------------------- */
function initHistorySearch() {
    const input = document.getElementById('history-search');
    const rows = document.querySelectorAll('#history-table tbody tr');

    input.addEventListener('input', () => {
        const term = input.value.toLowerCase();
        rows.forEach(row => {
            const text = row.innerText.toLowerCase();
            row.style.display = text.includes(term) ? '' : 'none';
        });
    });
}

/* ---------------------------------------------------------------
   Confirm before deleting a saved description
--------------------------------------------------------------- */
function initDeleteConfirmations() {
    document.querySelectorAll('.delete-form').forEach(form => {
        form.addEventListener('submit', (e) => {
            if (!confirm('Delete this description permanently?')) {
                e.preventDefault();
            }
        });
    });
}
