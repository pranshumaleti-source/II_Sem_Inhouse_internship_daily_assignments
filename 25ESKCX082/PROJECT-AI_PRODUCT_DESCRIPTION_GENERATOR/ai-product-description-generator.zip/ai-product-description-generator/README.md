# AI Product Description Generator

A full-stack web application built with **HTML, CSS, JavaScript, and PHP (MySQL)** as a capstone project for a 15-day Full Stack Web Development training program.

The tool takes basic product details (name, category, features, tone, audience) and instantly generates a marketing-ready product description along with SEO keyword suggestions — the same task an AI copywriting tool performs — using a custom rule-based generation engine written in PHP.

---

## 1. Objective

Online sellers often struggle to write unique, appealing product descriptions for every item in their catalog. This project automates that process: the user fills a short form, and the system generates a ready-to-use description in seconds, which can be copied, saved, searched, edited, or deleted later.

## 2. Tech Stack

| Layer          | Technology                          |
|----------------|--------------------------------------|
| Structure      | HTML5                               |
| Styling        | CSS3 (custom, responsive, no framework) |
| Interactivity  | Vanilla JavaScript (Fetch API / AJAX) |
| Server Logic   | PHP 8 (procedural, MySQLi)          |
| Database       | MySQL                               |
| Auth           | PHP Sessions + `password_hash()` / `password_verify()` |

## 3. Features

- **AI-style description generation** — a template/rule-based engine (`includes/generator.php`) that varies sentence structure, vocabulary, and SEO keywords based on tone (Professional, Casual, Luxury, Playful, Minimal), so results feel freshly written rather than copy-pasted.
- **Live "typing" animation** on the result, and instant word count.
- **AJAX form submission** — no page reloads when generating a description.
- **Copy to clipboard** button.
- **Save to History (MySQL)** — persist any generated description.
- **History page** with live client-side search/filter across all saved descriptions.
- **Admin login** (session-based) protecting Edit and Delete actions.
- **Full CRUD**: Create (generate + save), Read (history), Update (edit.php, with an option to regenerate), Delete (delete.php, with confirmation).
- **Responsive design** — works on mobile, tablet, and desktop.
- **SQL Injection safe** — all queries use prepared statements (MySQLi `bind_param`).

## 4. Folder Structure

```
ai-product-description-generator/
├── config/
│   └── db.php              # Database connection
├── includes/
│   ├── header.php          # Shared navbar/head
│   ├── footer.php          # Shared footer/scripts
│   ├── generator.php       # Core description-generation engine
│   └── auth.php            # requireAdmin() session guard
├── assets/
│   ├── css/style.css       # All styling
│   └── js/script.js        # AJAX + UI interactivity
├── database/
│   └── schema.sql          # Database + tables + seed data
├── index.php                # Generator form (home page)
├── generate.php              # AJAX endpoint: generates description (no DB write)
├── save.php                  # AJAX endpoint: saves description to DB
├── history.php                # View / search saved descriptions
├── edit.php                   # Admin: edit a saved description
├── delete.php                  # Admin: delete a saved description
├── login.php / logout.php     # Admin authentication
└── README.md
```

## 5. Database Design

**`descriptions`** — id, product_name, category, features, tone, audience, description, seo_keywords, word_count, created_at, updated_at

**`admins`** — id, username, password (bcrypt hash), created_at

## 6. Setup Instructions (XAMPP / WAMP / LAMP)

1. Copy the `ai-product-description-generator` folder into your server's web root
   (e.g. `htdocs` for XAMPP, `www` for WAMP).
2. Start **Apache** and **MySQL** from your control panel.
3. Open **phpMyAdmin** → Import → select `database/schema.sql` and run it.
   This creates the database, both tables, the seed admin account, and one sample record.
4. If your MySQL root user has a password, update it in `config/db.php`:
   ```php
   define('DB_PASS', 'your_mysql_password');
   ```
5. Visit `http://localhost/ai-product-description-generator/` in your browser.
6. To test admin features (Edit/Delete), go to **Admin Login** and use:
   - Username: `admin`
   - Password: `admin123`

## 7. How the "AI" Generation Works

Since a real AI API key isn't required for this project, `includes/generator.php` implements a **rule-based natural language generation engine**:

1. Splits the comma-separated features into a natural list ("a, b, and c").
2. Picks tone-appropriate opening, connector, closing, and call-to-action sentence templates at random.
3. Fills placeholders (`{name}`, `{category}`, `{audience}`) into the chosen templates.
4. Assembles the final paragraph and computes a word count.
5. Separately generates SEO keyword suggestions from the product name, category, features, and audience.

Because templates and feature ordering are chosen randomly each time, the same input rarely produces an identical result twice — closely mimicking generative AI output while running **100% offline**, with no API costs or keys required.

A commented example at the bottom of `generator.php` shows exactly how to swap this engine for a real OpenAI/Claude/Gemini API call if desired.

## 8. Future Scope

- Integrate a real AI model (OpenAI/Claude API) as a toggleable "Pro mode".
- Multi-language description generation.
- Export descriptions as CSV/PDF in bulk.
- Multi-admin roles and per-user history.
- Image-based description generation (upload a product photo).

## 9. Author

Submitted as a capstone project for the 15-Day Full Stack Web Development Training Program.
