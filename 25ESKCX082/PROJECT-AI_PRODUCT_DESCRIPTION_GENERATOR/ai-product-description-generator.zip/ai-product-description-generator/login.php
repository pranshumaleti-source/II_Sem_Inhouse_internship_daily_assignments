<?php
require 'config/db.php';
if (session_status() === PHP_SESSION_NONE) session_start();

if (isset($_SESSION['admin_id'])) {
    header('Location: history.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    $stmt = $conn->prepare("SELECT id, username, password FROM admins WHERE username = ?");
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $admin = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($admin && password_verify($password, $admin['password'])) {
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_username'] = $admin['username'];
        header('Location: history.php');
        exit;
    } else {
        $error = 'Invalid username or password.';
    }
}

$pageTitle = "Admin Login";
include 'includes/header.php';
?>

<div class="login-wrap">
    <div class="card">
        <h2 style="text-align:center;">Admin Login</h2>
        <p style="text-align:center; color:var(--muted); font-size:0.88rem;">Log in to edit or delete saved descriptions.</p>

        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <form method="POST">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required style="margin-bottom:16px;">

            <label for="password">Password</label>
            <input type="password" id="password" name="password" required style="margin-bottom:20px;">

            <button type="submit" class="btn btn-primary" style="width:100%; justify-content:center;">Log In</button>
        </form>

        <p style="text-align:center; font-size:0.8rem; color:var(--muted); margin-top:16px;">
            Default demo credentials: <code>admin</code> / <code>admin123</code>
        </p>
    </div>
</div>

<?php
$conn->close();
include 'includes/footer.php';
?>
