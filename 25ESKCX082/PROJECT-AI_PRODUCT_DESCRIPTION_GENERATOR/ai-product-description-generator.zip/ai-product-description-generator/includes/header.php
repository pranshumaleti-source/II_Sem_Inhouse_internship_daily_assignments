<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' | AI Product Description Generator' : 'AI Product Description Generator'; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <header class="navbar">
        <div class="container navbar-inner">
            <a href="index.php" class="logo">✨ AI Desc<span>Gen</span></a>
            <nav>
                <a href="index.php">Generator</a>
                <a href="history.php">History</a>
                <?php if (isset($_SESSION['admin_id'])): ?>
                    <a href="logout.php">Logout (<?php echo htmlspecialchars($_SESSION['admin_username']); ?>)</a>
                <?php else: ?>
                    <a href="login.php">Admin Login</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>
    <main class="container">
