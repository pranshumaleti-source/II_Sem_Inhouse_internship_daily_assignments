<?php
/**
 * ===================================================================
 * AI-STYLE PRODUCT DESCRIPTION GENERATION ENGINE
 * ===================================================================
 * This is a rule-based / template generation engine written in pure
 * PHP. It varies sentence structure, vocabulary, and tone every time
 * it runs, so the same inputs rarely produce the exact same output —
 * simulating how an AI copywriter would draft marketing copy.
 *
 * WANT TO USE A REAL AI MODEL INSTEAD?
 * See the commented "callRealAI()" function at the bottom of this file
 * for how you'd swap this out for an OpenAI / Claude / Gemini API call.
 * ===================================================================
 */

function generateProductDescription($productName, $category, $featuresRaw, $tone, $audience)
{
    // Split comma separated features into a clean array
    $features = array_filter(array_map('trim', explode(',', $featuresRaw)));
    if (empty($features)) {
        $features = ['great quality', 'reliable performance'];
    }

    // ---------------------------------------------------------
    // Tone-based phrase banks
    // ---------------------------------------------------------
    $openers = [
        'professional' => [
            "Introducing the {name}, designed to deliver exceptional results for {audience}.",
            "The {name} is engineered to meet the needs of {audience} with precision and reliability.",
            "Meet the {name} — a {category} built for {audience} who expect nothing less than the best.",
        ],
        'casual' => [
            "Say hello to the {name}! It's exactly what {audience} have been looking for.",
            "Looking for a {category} that just gets you? The {name} has your back.",
            "The {name} is here, and honestly, {audience} are going to love it.",
        ],
        'luxury' => [
            "Indulge in the {name}, a refined {category} crafted exclusively for {audience}.",
            "Presenting the {name} — where craftsmanship meets elegance, made for {audience}.",
            "Discover the {name}, an exquisite addition for {audience} who appreciate the finer things.",
        ],
        'playful' => [
            "Meet your new favorite thing: the {name}! Perfect for {audience} who love a little fun.",
            "The {name} just walked in and stole the show — {audience}, get ready to smile.",
            "Guess what {audience} are obsessed with right now? The {name}, of course!",
        ],
        'minimal' => [
            "The {name}. Simple, effective, made for {audience}.",
            "{name} — a {category} that does exactly what it promises.",
            "Less noise, more function. The {name}, built for {audience}.",
        ],
    ];

    $featureConnectors = [
        "It comes packed with %s, giving you everything you need in one place.",
        "Featuring %s, this %s stands out from the rest.",
        "With %s, you get a level of quality that's hard to beat.",
        "Highlights include %s — thoughtfully combined for everyday use.",
        "Designed with %s, it's built to perform when it matters most.",
    ];

    $benefitClosers = [
        'professional' => [
            "Whether at work or on the go, the {name} adapts to your lifestyle with ease.",
            "It's a dependable choice for {audience} who value consistency and quality.",
        ],
        'casual' => [
            "No fuss, no complications — just a {category} that works the way you want it to.",
            "Trust us, once {audience} try the {name}, there's no going back.",
        ],
        'luxury' => [
            "Every detail of the {name} reflects a commitment to timeless quality.",
            "It's more than a {category} — it's a statement piece for {audience}.",
        ],
        'playful' => [
            "Trust us, this {category} brings the fun back into everyday life.",
            "{audience} won't just like it, they'll want to tell everyone about it!",
        ],
        'minimal' => [
            "No distractions. Just a {category} that delivers.",
            "Built with intention, made for {audience}.",
        ],
    ];

    $callToActions = [
        "Grab your {name} today and experience the difference for yourself.",
        "Don't wait — add the {name} to your cart and see why {audience} are switching.",
        "Ready to upgrade? The {name} is just one click away.",
        "Get your {name} now — because {audience} deserve the best.",
    ];

    // ---------------------------------------------------------
    // Fallback to 'professional' tone if an unknown tone is passed
    // ---------------------------------------------------------
    $tone = array_key_exists($tone, $openers) ? $tone : 'professional';
    $audienceText = !empty($audience) ? $audience : 'everyday users';

    // ---------------------------------------------------------
    // Build the description
    // ---------------------------------------------------------
    $opener = pickRandom($openers[$tone]);
    $connector = pickRandom($featureConnectors);
    $closer = pickRandom($benefitClosers[$tone]);
    $cta = pickRandom($callToActions);

    // Turn feature list into a natural comma+"and" separated string
    $featureText = joinFeaturesNaturally($features);

    $sentence1 = fillTemplate($opener, $productName, $category, $audienceText);
    $sentence2 = sprintf($connector, $featureText, strtolower($category));
    $sentence3 = fillTemplate($closer, $productName, $category, $audienceText);
    $sentence4 = fillTemplate($cta, $productName, $category, $audienceText);

    $fullDescription = $sentence1 . ' ' . $sentence2 . ' ' . $sentence3 . ' ' . $sentence4;
    $fullDescription = preg_replace('/\s+/', ' ', trim($fullDescription));

    // ---------------------------------------------------------
    // SEO keyword suggestions
    // ---------------------------------------------------------
    $seoKeywords = generateSeoKeywords($productName, $category, $features, $audienceText);

    return [
        'description'  => $fullDescription,
        'seo_keywords' => $seoKeywords,
        'word_count'   => str_word_count($fullDescription),
    ];
}

/** Pick a random element from an array */
function pickRandom($arr)
{
    return $arr[array_rand($arr)];
}

/** Replace {name}, {category}, {audience} placeholders */
function fillTemplate($template, $name, $category, $audience)
{
    return str_replace(
        ['{name}', '{category}', '{audience}'],
        [$name, strtolower($category), $audience],
        $template
    );
}

/** Turn ['a','b','c'] into "a, b, and c" */
function joinFeaturesNaturally($features)
{
    $features = array_values($features);
    $count = count($features);
    if ($count === 1) return $features[0];
    if ($count === 2) return $features[0] . ' and ' . $features[1];

    $last = array_pop($features);
    return implode(', ', $features) . ', and ' . $last;
}

/** Generate a comma separated SEO keyword string */
function generateSeoKeywords($productName, $category, $features, $audience)
{
    $keywords = [];
    $keywords[] = $productName;
    $keywords[] = $category;
    $keywords[] = 'buy ' . strtolower($category) . ' online';
    $keywords[] = 'best ' . strtolower($category) . ' for ' . strtolower($audience);

    foreach (array_slice($features, 0, 3) as $f) {
        $keywords[] = strtolower($f);
    }

    return implode(', ', array_unique($keywords));
}

/**
 * ===================================================================
 * OPTIONAL BONUS: connecting a REAL AI model instead of the engine above
 * ===================================================================
 * If your training program allows using a paid/free AI API key, you can
 * replace the call in generate.php with something like this:
 *
 * function callRealAI($productName, $category, $features, $tone, $audience) {
 *     $apiKey = 'YOUR_OPENAI_API_KEY';
 *     $prompt = "Write a $tone product description for a $category called
 *                '$productName' with features: $features, targeted at $audience.";
 *
 *     $ch = curl_init('https://api.openai.com/v1/chat/completions');
 *     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 *     curl_setopt($ch, CURLOPT_POST, true);
 *     curl_setopt($ch, CURLOPT_HTTPHEADER, [
 *         'Content-Type: application/json',
 *         'Authorization: Bearer ' . $apiKey
 *     ]);
 *     curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
 *         'model' => 'gpt-4o-mini',
 *         'messages' => [['role' => 'user', 'content' => $prompt]]
 *     ]));
 *     $response = json_decode(curl_exec($ch), true);
 *     curl_close($ch);
 *     return $response['choices'][0]['message']['content'] ?? 'Error generating description.';
 * }
 * ===================================================================
 */
