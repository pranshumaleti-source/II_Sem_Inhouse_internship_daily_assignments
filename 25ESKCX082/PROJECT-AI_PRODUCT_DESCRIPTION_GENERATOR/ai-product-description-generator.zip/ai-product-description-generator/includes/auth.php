<?php
if (session_status() === PHP_SESSION_NONE) session_start();

/** Call this at the top of any page that should be admin-only */
function requireAdmin()
{
    if (!isset($_SESSION['admin_id'])) {
        header('Location: login.php');
        exit;
    }
}
