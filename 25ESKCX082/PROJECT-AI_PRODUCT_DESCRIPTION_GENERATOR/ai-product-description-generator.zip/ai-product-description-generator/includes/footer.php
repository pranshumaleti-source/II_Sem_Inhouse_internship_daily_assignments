    </main>
    <footer class="site-footer">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> AI Product Description Generator &mdash; Built with HTML, CSS, JS &amp; PHP for Full Stack Training Project.</p>
        </div>
    </footer>
    <script src="assets/js/script.js"></script>
</body>
</html>
