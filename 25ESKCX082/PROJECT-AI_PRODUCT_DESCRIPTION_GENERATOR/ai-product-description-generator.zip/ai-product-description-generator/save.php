<?php
/**
 * AJAX endpoint: saves a previously generated description into the
 * database (called when the user clicks "Save to History").
 */
header('Content-Type: application/json');
require 'config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Invalid request method']);
    exit;
}

$productName = trim($_POST['product_name'] ?? '');
$category    = trim($_POST['category'] ?? '');
$features    = trim($_POST['features'] ?? '');
$tone        = trim($_POST['tone'] ?? '');
$audience    = trim($_POST['audience'] ?? '');
$description = trim($_POST['description'] ?? '');
$seoKeywords = trim($_POST['seo_keywords'] ?? '');
$wordCount   = (int)($_POST['word_count'] ?? 0);

if ($productName === '' || $description === '') {
    http_response_code(422);
    echo json_encode(['error' => 'Missing required data to save.']);
    exit;
}

$stmt = $conn->prepare(
    "INSERT INTO descriptions (product_name, category, features, tone, audience, description, seo_keywords, word_count)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
);
$stmt->bind_param('sssssssi', $productName, $category, $features, $tone, $audience, $description, $seoKeywords, $wordCount);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'id' => $stmt->insert_id]);
} else {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to save to database.']);
}

$stmt->close();
$conn->close();
