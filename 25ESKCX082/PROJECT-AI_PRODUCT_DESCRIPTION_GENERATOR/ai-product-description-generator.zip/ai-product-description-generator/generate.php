<?php
/**
 * AJAX endpoint: receives form data via POST, runs it through the
 * generation engine, and returns JSON. Does NOT touch the database —
 * saving is a separate explicit step (save.php) triggered by the
 * "Save to History" button.
 */
header('Content-Type: application/json');
require 'includes/generator.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Invalid request method']);
    exit;
}

$productName = trim($_POST['product_name'] ?? '');
$category    = trim($_POST['category'] ?? '');
$features    = trim($_POST['features'] ?? '');
$tone        = trim($_POST['tone'] ?? 'professional');
$audience    = trim($_POST['audience'] ?? '');

if ($productName === '' || $category === '' || $features === '') {
    http_response_code(422);
    echo json_encode(['error' => 'Product name, category, and features are required.']);
    exit;
}

// Basic sanitisation (strip tags to avoid stored/reflected XSS)
$productName = strip_tags($productName);
$category    = strip_tags($category);
$features    = strip_tags($features);
$tone        = strip_tags($tone);
$audience    = strip_tags($audience);

$result = generateProductDescription($productName, $category, $features, $tone, $audience);

echo json_encode([
    'success'      => true,
    'product_name' => $productName,
    'category'     => $category,
    'features'     => $features,
    'tone'         => $tone,
    'audience'     => $audience,
    'description'  => $result['description'],
    'seo_keywords' => $result['seo_keywords'],
    'word_count'   => $result['word_count'],
]);
