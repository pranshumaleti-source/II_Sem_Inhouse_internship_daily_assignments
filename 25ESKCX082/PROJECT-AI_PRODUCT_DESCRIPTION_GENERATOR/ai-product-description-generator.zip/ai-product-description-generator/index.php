<?php
$pageTitle = "Generator";
include 'includes/header.php';
?>

<section class="hero">
    <span class="eyebrow">⚡ rule-based generation engine</span>
    <h1>Turn product details into ready-to-use descriptions</h1>
    <p>Fill in a few details below and get a marketing-ready product description with SEO keyword suggestions, instantly.</p>
</section>

<div class="card">
    <form id="generator-form">
        <div class="form-grid">
            <div class="full">
                <label for="product_name">Product Name</label>
                <input type="text" id="product_name" name="product_name" placeholder="e.g. AeroFit Running Shoes" required maxlength="150">
            </div>

            <div>
                <label for="category">Category</label>
                <input type="text" id="category" name="category" placeholder="e.g. Footwear, Electronics" required maxlength="100">
            </div>

            <div>
                <label for="tone">Tone <span class="hint">of voice</span></label>
                <select id="tone" name="tone" required>
                    <option value="professional">Professional</option>
                    <option value="casual">Casual</option>
                    <option value="luxury">Luxury</option>
                    <option value="playful">Playful</option>
                    <option value="minimal">Minimal</option>
                </select>
            </div>

            <div class="full">
                <label for="features">Key Features <span class="hint">(comma separated)</span></label>
                <textarea id="features" name="features" placeholder="e.g. lightweight mesh upper, breathable, shock-absorbing sole" required></textarea>
            </div>

            <div class="full">
                <label for="audience">Target Audience <span class="hint">(optional)</span></label>
                <input type="text" id="audience" name="audience" placeholder="e.g. fitness enthusiasts and daily runners" maxlength="100">
            </div>
        </div>

        <div class="actions-row">
            <button type="submit" class="btn btn-primary" id="generate-btn">✨ Generate Description</button>
            <button type="reset" class="btn btn-secondary">Clear Form</button>
        </div>

        <div class="loader" id="loader">
            <div class="spinner"></div>
            <span>Generating your description...</span>
        </div>
    </form>
</div>

<div class="card" id="result-panel">
    <div class="result-meta">
        <span id="word-count">0 words</span>
        <div class="actions-row" style="margin-top:0;">
            <button class="btn btn-sm btn-secondary" id="copy-btn" type="button">📋 Copy</button>
            <button class="btn btn-sm btn-secondary" id="save-btn" type="button">💾 Save to History</button>
        </div>
    </div>
    <p id="generated-text"></p>

    <div>
        <label style="margin-top:8px;">Suggested SEO Keywords</label>
        <div class="tags" id="seo-tags"></div>
    </div>
</div>

<div id="save-confirmation"></div>

<?php include 'includes/footer.php'; ?>
