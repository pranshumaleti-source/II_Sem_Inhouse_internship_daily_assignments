<?php
require 'includes/auth.php';
requireAdmin();
require 'config/db.php';
require 'includes/generator.php';

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$errors = [];

// Fetch existing record
$stmt = $conn->prepare("SELECT * FROM descriptions WHERE id = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$record = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$record) {
    header('Location: history.php');
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productName = trim($_POST['product_name'] ?? '');
    $category    = trim($_POST['category'] ?? '');
    $features    = trim($_POST['features'] ?? '');
    $tone        = trim($_POST['tone'] ?? '');
    $audience    = trim($_POST['audience'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $regenerate  = isset($_POST['regenerate']);

    if ($productName === '' || $category === '' || $features === '' || $description === '') {
        $errors[] = 'All required fields must be filled in.';
    }

    if ($regenerate && empty($errors)) {
        $result = generateProductDescription($productName, $category, $features, $tone, $audience);
        $description = $result['description'];
        $seoKeywords = $result['seo_keywords'];
        $wordCount = $result['word_count'];
    } else {
        $seoKeywords = trim($_POST['seo_keywords'] ?? '');
        $wordCount = str_word_count($description);
    }

    if (empty($errors)) {
        $update = $conn->prepare(
            "UPDATE descriptions SET product_name=?, category=?, features=?, tone=?, audience=?, description=?, seo_keywords=?, word_count=? WHERE id=?"
        );
        $update->bind_param('sssssssii', $productName, $category, $features, $tone, $audience, $description, $seoKeywords, $wordCount, $id);
        $update->execute();
        $update->close();
        $conn->close();
        header('Location: history.php?updated=1');
        exit;
    }

    // keep edited values on screen if there were errors
    $record = array_merge($record, compact('productName', 'category', 'features', 'tone', 'audience', 'description'));
}

$pageTitle = "Edit Description";
include 'includes/header.php';
?>

<section class="hero" style="padding-top:32px;">
    <h1>Edit Description</h1>
    <p>Update the details below and save, or regenerate a fresh version using the current inputs.</p>
</section>

<?php foreach ($errors as $err): ?>
    <div class="alert alert-error"><?php echo htmlspecialchars($err); ?></div>
<?php endforeach; ?>

<div class="card">
    <form method="POST">
        <input type="hidden" name="id" value="<?php echo $record['id']; ?>">
        <div class="form-grid">
            <div class="full">
                <label for="product_name">Product Name</label>
                <input type="text" id="product_name" name="product_name" value="<?php echo htmlspecialchars($record['product_name']); ?>" required>
            </div>
            <div>
                <label for="category">Category</label>
                <input type="text" id="category" name="category" value="<?php echo htmlspecialchars($record['category']); ?>" required>
            </div>
            <div>
                <label for="tone">Tone</label>
                <select id="tone" name="tone">
                    <?php foreach (['professional','casual','luxury','playful','minimal'] as $t): ?>
                        <option value="<?php echo $t; ?>" <?php echo $record['tone'] === $t ? 'selected' : ''; ?>><?php echo ucfirst($t); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="full">
                <label for="features">Key Features</label>
                <textarea id="features" name="features" required><?php echo htmlspecialchars($record['features']); ?></textarea>
            </div>
            <div class="full">
                <label for="audience">Target Audience</label>
                <input type="text" id="audience" name="audience" value="<?php echo htmlspecialchars($record['audience']); ?>">
            </div>
            <div class="full">
                <label for="description">Description</label>
                <textarea id="description" name="description" style="min-height:160px;" required><?php echo htmlspecialchars($record['description']); ?></textarea>
            </div>
            <div class="full">
                <label for="seo_keywords">SEO Keywords</label>
                <input type="text" id="seo_keywords" name="seo_keywords" value="<?php echo htmlspecialchars($record['seo_keywords']); ?>">
            </div>
        </div>

        <div class="actions-row">
            <button type="submit" class="btn btn-primary">💾 Save Changes</button>
            <button type="submit" name="regenerate" value="1" class="btn btn-secondary">🔁 Regenerate with AI Engine</button>
            <a href="history.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>

<?php include 'includes/footer.php'; ?>
